<?php
require_once 'config.php';
header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    
    <link rel="icon" href="/static/pictures/favicon.ico" type="image/x-icon">
    <link rel="icon" href="https://pixelmath.ru/static/pictures/favicon.ico" type="image/x-icon">
    <!-- Yandex.Metrika counter -->
    <script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();
   for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
   k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(101089544, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true
   });
    </script>
    <noscript><div><img src="https://mc.yandex.ru/watch/101089544" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
    <!-- /Yandex.Metrika counter -->
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Порешаем? | Подготовка к ЕГЭ по математике бесплатно</title>
    <meta name="description" content="Бесплатная подготовка к ЕГЭ по математике: задания, решения, практика. Начни прямо сейчас и улучши свои результаты!">
    <meta name="keywords" content="ЕГЭ математика, подготовка к ЕГЭ, задания ЕГЭ, решения ЕГЭ, бесплатные уроки математики, задания ЕГЭ математика, практика ЕГЭ, решения задач ЕГЭ, подготовка к ЕГЭ, математика онлайн">
    <link rel="stylesheet" href="/static/CSS/main.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Anonymous+Pro:ital,wght@0,400;0,700;1,400&display=swap">
</head>
<body>
    <div class="overlay"></div>
    <div class="particles-container"></div>
    <div class="content-wrapper">
        <div class="main_text">
            <h1>Порешаем? Подготовка к ЕГЭ по математике</h1>
            <p class="subtitle">Всё бесплатно</p>
            <div class="retro rbtn-big" id="start-button">Начать</div>
            <p class="description">Кликни “Начать” и практикуй <strong>задания ЕГЭ по математике</strong> онлайн. Бесплатные уроки и решения помогут тебе подготовиться к экзамену и повысить баллы!</p>
        </div>
        <div class="equations-container">
            <div id="typewriter-left" class="typewriter-column"></div>
            <div id="typewriter-right" class="typewriter-column"></div>
        </div>
    </div>
    <div class="section about">
        <h2 class="seo-hidden">О сайте: Бесплатная помощь в подготовке к ЕГЭ</h2>
        <p>Этот сайт создан для тех, кто хочет быстро и эффективно подготовиться к ЕГЭ по математике. Мы предлагаем бесплатные задания, решения и объяснения, чтобы ты мог практиковаться в любое время.</p>
    </div>
    <div class="section_features">
        <div class="section_fearurse_left">
            <div class="section_fearurse_left_center">
                <h2 class="seo-hidden">Что мы предлагаем для подготовки к ЕГЭ</h2>
                <div class="section_fearurse_left_ul">
                    <ul>
                        <li>➜ Пошаговые <strong>решения задач ЕГЭ</strong></li>
                        <li>➜ Интерактивные <strong>примеры ЕГЭ по математике</strong></li>
                        <li>➜ Доступ к практике <strong>ЕГЭ 24/7</strong></li>
                        <li>➜ Простой интерфейс для подготовки к <strong>ЕГЭ онлайн</strong></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="section_fearurse_img">
            <img class="example_img" src="/static/pictures/example.png" alt="Пример задания ЕГЭ по математике">
        </div>
    </div>
    
    <div class="section_features">
        <div class="section_fearurse_left">
            <div class="section_fearurse_left_center">
                <h2 class="seo-hidden">Что мы предлагаем для подготовки к ЕГЭ</h2>
                <div class="section_fearurse_left_ul">
                    <ul>
                        <li>➜ Подготовка к ОГЭ <strong</strong></li>
                        <li>➜ Подготовка к ЕГЭ (базовый и профильный уровень)<strong></strong></li>
                        <li>➜ Повышение успеваемости<strong></strong></li>
                        <li>➜ Помощь с домашней работой<strong></strong></li>
                        <li>➜ тг <strong>@ralifgrannik</strong></li>
                        </ul>
                </div>
            </div>
        </div>

        <div class="section_fearurse_img">
            <img class="example_img" src="/static/pictures/lessen.png" alt="Индивидуальные занятия. Услуги репетитора">
        </div>
    </div>
    
    
    
    <div class="section contact">
        <h2>Связаться с нами</h2>
        <p>Есть вопросы? Пиши нам на <a href="mailto:mathproba@mail.ru">mathpix@inbox.ru</a> или оставляй комментарии в нашем сообществе!</p>
    </div>
    <audio id="optimus-theme" src="/static/audio/optimus_theme.mp3" loading="lazy"></audio>
    <script src="/static/scripts/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js" async></script>
</body>
</html>